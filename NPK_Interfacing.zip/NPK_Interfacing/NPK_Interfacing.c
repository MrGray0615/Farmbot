#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/uart.h"
#include "hardware/gpio.h"

#define UART_ID        uart0
#define UART_BAUD      4800          // Or 9600, set as needed
#define UART_TX_PIN    0             // GP0 (UART0 TX default)
#define UART_RX_PIN    1             // GP1 (UART0 RX default)

#define DE_PIN         7             // GP7 RS485 Driver Enable (Transmit mode)
#define RE_PIN         8             // GP8 RS485 Receiver Enable (Receive mode)

// Read 7 registers starting at 0x0000, function 0x03
static const uint8_t MULTI_REQ[8] = {
    0x01, 0x03, 0x00, 0x00, 0x00, 0x07, 0x04, 0x08
};

// CRC16-Modbus calculation
uint16_t crc16_modbus(const uint8_t *buf, int len) {
    uint16_t crc = 0xFFFF;
    for (int pos = 0; pos < len; pos++) {
        crc ^= (uint16_t)buf[pos];
        for (int i = 8; i != 0; i--) {
            if ((crc & 0x0001) != 0) {
                crc >>= 1;
                crc ^= 0xA001;
            } else {
                crc >>= 1;
            }
        }
    }
    return crc;
}

static void rs485_tx_enable(bool enable) {
    gpio_put(DE_PIN, enable ? 1 : 0);
    gpio_put(RE_PIN, enable ? 1 : 0);
}

static int read_bytes_with_timeout(uint8_t *buf, int max_len, uint32_t timeout_ms) {
    absolute_time_t deadline = make_timeout_time_ms(timeout_ms);
    int idx = 0;
    while (absolute_time_diff_us(get_absolute_time(), deadline) > 0 && idx < max_len) {
        if (uart_is_readable(UART_ID)) {
            buf[idx++] = (uint8_t)uart_getc(UART_ID);
        }
        tight_loop_contents();
    }
    return idx;
}

int main() {
    stdio_init_all();

    gpio_init(DE_PIN);
    gpio_set_dir(DE_PIN, GPIO_OUT);
    gpio_init(RE_PIN);
    gpio_set_dir(RE_PIN, GPIO_OUT);

    // Default to receive mode
    gpio_put(DE_PIN, 0);
    gpio_put(RE_PIN, 0);

    uart_init(UART_ID, UART_BAUD);
    gpio_set_function(UART_TX_PIN, GPIO_FUNC_UART);
    gpio_set_function(UART_RX_PIN, GPIO_FUNC_UART);
    uart_set_format(UART_ID, 8, 1, UART_PARITY_NONE);
    uart_set_fifo_enabled(UART_ID, true);

    puts("ZTS-3002 Sensor Starting...");

    while (true) {
        while (uart_is_readable(UART_ID)) (void)uart_getc(UART_ID); // flush input 

        // Transmit request
        rs485_tx_enable(true);
        sleep_us(100);               // slight delay before TX
        uart_write_blocking(UART_ID, MULTI_REQ, sizeof(MULTI_REQ));
        uart_tx_wait_blocking(UART_ID);
        sleep_us(100);               // delay to allow last bit to transmit fully
        rs485_tx_enable(false);      // set receive mode

        // Read response
        uint8_t buf[64];
        int n = read_bytes_with_timeout(buf, sizeof(buf), 2000); // 2 sec timeout

        printf("Raw (%d bytes): ", n);
        for (int i = 0; i < n; i++) {
            printf("%02X ", buf[i]);
        }
        printf("\n");

        if (n < 5) {
            printf("Response too short.\n");
            sleep_ms(2000);
            continue;
        }

        // CRC check of received bytes (last two bytes are CRC low byte then high byte)
        uint16_t crc_calc = crc16_modbus(buf, n - 2);
        uint16_t crc_recv = (uint16_t)buf[n - 1] << 8 | buf[n - 2];
        if (crc_calc != crc_recv) {
            printf("CRC mismatch! Calculated %04X, received %04X\n", crc_calc, crc_recv);
            sleep_ms(2000);
            continue;
        }

        // Check Modbus header: address, function code, byte count validation
        if (buf[0] != 0x01 || buf[1] != 0x03 || buf[2] != 0x0E) {
            printf("Invalid Modbus header.\n");
            sleep_ms(2000);
            continue;
        }

        // Parse sensor data as per datasheet
        float moist = ((buf[3] << 8) | buf[4]) / 10.0f;
        float temp  = ((buf[5] << 8) | buf[6]) / 10.0f;
        uint16_t ec = (buf[7] << 8) | buf[8];
        float ph    = ((buf[9] << 8) | buf[10]) / 10.0f;
        uint16_t N  = (buf[11] << 8) | buf[12];
        uint16_t P  = (buf[13] << 8) | buf[14];
        uint16_t K  = (buf[15] << 8) | buf[16];

        printf("------ Sensor Readings ------\n");
        printf("Moisture:      %.1f %%\n", moist);
        printf("Temperature:   %.1f °C\n", temp);
        printf("EC:            %u µS/cm\n", ec);
        printf("pH:            %.1f\n", ph);
        printf("Nitrogen (N):  %u mg/kg\n", N);
        printf("Phosphorus (P):%u mg/kg\n", P);
        printf("Potassium (K): %u mg/kg\n", K);
        printf("------------------------------\n");

        sleep_ms(2000);
    }
}
